const Express = require('express')
const app = Express();

app.get('/', (req, res) => {
    console.log('get response')
    res.send('this is get request')
})

app.post('/', (req, res) => {
    console.log('post response')
    res.send('this is post request')
})

app.put('/', (req, res) => {
    console.log('put request')
    res.send('this is put request')
})

app.delete('/', (req, res) =>{
    console.log('delete request');
    res.send("this is delete request")
})

app.listen(3000, () => {
    console.log('server running on port 3000');
})