const names = [
    {
        rollNo: 42,
        stdname: 'hadi shah'
    },
    {
        rollNo: 38,
        stdname: 'annruggg sawant'
    }
]

setTimeout(()=>{
    console.log(names[1]);
}, 2000)

setTimeout(()=>{
    console.log(names[0]);
}, 3000)

console.log('list:');
